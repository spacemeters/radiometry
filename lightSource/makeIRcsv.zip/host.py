# The hosting file should have the URL to the server which hosts the latest version of spacemeters.py and related files.

# the variable shall be specified as follows
hostingURL = "http://200.61.170.210:8080//" #"https://raw.githubusercontent.com/spacemeters/serve/public/"
